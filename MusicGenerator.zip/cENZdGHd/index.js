// javascript
let music = ["Diamonds by Rihanna", "My Boo by Usher", "PokerFace by LadyGaga", "Bye Bye Bye by NSync", "Ms. Jackson by OutKast", "Oops! I did it again by Britney Spears", "Chop Suey! by System Of a Down"]


let musicDisplay = document.getElementById("music-el")
let generate = document.getElementById("btn-el")


 generate.addEventListener("click", function() {
   let randomIndex = Math.floor (Math.random() * music.length)
     musicDisplay.textContent = "Now playing... " + music[randomIndex]
 })
 
 
 // link video to text and box